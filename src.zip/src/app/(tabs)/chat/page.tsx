export default function ChatPage() {
    return <div className="p-5 text-center text-xl">채팅 페이지</div>;
  }
  