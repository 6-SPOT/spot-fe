"use client";

import React from "react";

export default function HomePage() {
  return (
    <div className="p-5 text-center text-xl">
      <h1 className="mb-4">홈 페이지</h1>
      {[...Array(50)].map((_, index) => (
        <p key={index} className="mb-2">
          이곳은 긴 콘텐츠 테스트 {index + 1}
        </p>
      ))}
    </div>
  );
}
