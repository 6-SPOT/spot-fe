export default function TasksPage() {
    return <div className="p-5 text-center text-xl">작업현황 페이지</div>;
  }
  