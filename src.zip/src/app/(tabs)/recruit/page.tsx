export default function RecruitPage() {
    return <div className="p-5 text-center text-xl">구인등록 페이지</div>;
  }
  