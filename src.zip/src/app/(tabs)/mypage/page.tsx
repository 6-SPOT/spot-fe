export default function MyPage() {
    return <div className="p-5 text-center text-xl">마이페이지</div>;
  }
  