"use client";

import { useEffect, useRef, useState } from "react";
import API_Manager from "../lib/API_Manager";

declare global {
  interface Window {
    Tmapv2: any;
    mapInstance?: any;
    marker?: any;
  }
}

interface MapComponentProps {
  mode: "geocoding" | "reverse-geocoding";
  address?: string;
  onConfirm?: (address: string, coords: { lat: number; lng: number }) => void;
}

export default function MapComponent({ mode, address, onConfirm }: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [centerCoords, setCenterCoords] = useState({ lat: 37.402399, lng: 127.101112 });
  const [currentAddress, setCurrentAddress] = useState("주소 검색 중...");
  const TMAP_API_KEY = process.env.NEXT_PUBLIC_TMAP_API_KEY;

  useEffect(() => {
    if (window.Tmapv2 && typeof window.Tmapv2.LatLng === "function") {
      if (!window.mapInstance) {
        window.mapInstance = new window.Tmapv2.Map(mapRef.current!, {
          center: new window.Tmapv2.LatLng(centerCoords.lat, centerCoords.lng),
          width: "100%",
          height: "100%",
          zoom: 17,
          httpsMode: true,
        });

        window.marker = new window.Tmapv2.Marker({
          position: new window.Tmapv2.LatLng(centerCoords.lat, centerCoords.lng),
          map: window.mapInstance,
        });

        if (mode === "reverse-geocoding") {
          window.Tmapv2.event.addListener(window.mapInstance, "dragend", () => {
            const newCenter = window.mapInstance.getCenter();
            setCenterCoords({ lat: newCenter.lat(), lng: newCenter.lng() });
            requestReverseGeocoding(newCenter.lat(), newCenter.lng());
          });
        }
        setIsMapLoaded(true);
      }
    } else {
      setTimeout(() => setIsMapLoaded(true), 500);
    }
  }, []);

  useEffect(() => {
    if (!isMapLoaded) return; // 🌟 맵이 로드되기 전에 실행하지 않음
    if (mode === "geocoding" && address) {
      console.log("🟢 지오코딩 실행", address);
      requestGeocoding(address);
    } else if (mode === "reverse-geocoding") {
      console.log("🔴 리버스 지오코딩 실행", centerCoords);
      requestReverseGeocoding(centerCoords.lat, centerCoords.lng);
    }
  }, [mode, address]); // 🚨 isMapLoaded 제거 (불필요한 리렌더 방지)
  

  async function requestGeocoding(address: string) {
    if (!TMAP_API_KEY) return console.error("🚨 TMAP_API_KEY가 없습니다.");

    try {
      const encodedAddress = encodeURIComponent(address);
      const response = await API_Manager.get(
        "https://apis.openapi.sk.com/tmap/geo/fullAddrGeo",
        {
          version: "1",
          format: "json",
          appKey: TMAP_API_KEY,
          coordType: "WGS84GEO",
          addressFlag: "F02",
          fullAddr: encodedAddress,
        },
        {},
        { skipAuth: true, useSerializer: true }
      );
      const { newLat, newLon } = response.coordinateInfo.coordinate[0];
      setCenterCoords({ lat: parseFloat(newLat), lng: parseFloat(newLon) });
    } catch (error) {
      console.error("🚨 Geocoding 요청 실패:", error);
    }
  }

  async function requestReverseGeocoding(lat: number, lng: number) {
    if (!TMAP_API_KEY) return console.error("🚨 TMAP_API_KEY가 없습니다.");

    try {
      const response = await API_Manager.get(
        "https://apis.openapi.sk.com/tmap/geo/reverseGeo",
        {
          version: "1",
          format: "json",
          appKey: TMAP_API_KEY,
          coordType: "WGS84GEO",
          addressType: "A10",
          lat,
          lon: lng,
        },
        {},
        { skipAuth: true, useSerializer: true }
      );

      setCurrentAddress(response.addressInfo.fullAddress);
    } catch (error) {
      console.error("🚨 리버스 지오코딩 요청 실패:", error);
      setCurrentAddress("주소를 가져올 수 없습니다.");
    }
  }

  return (
    <div className="w-full h-full relative">
      <div ref={mapRef} className="w-full h-full" />
      {mode === "reverse-geocoding" && (
        <button
          onClick={() => onConfirm?.(currentAddress, centerCoords)}
          className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-4 py-2 rounded-md"
        >
          확인
        </button>
      )}
    </div>
  );
}
